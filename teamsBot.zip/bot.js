// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { TeamsActivityHandler } = require('botbuilder');

class TeamsBot extends TeamsActivityHandler {
    constructor() {
        super();
        this.onMembersAdded(async (context, next) => {
            const membersAdded = context.activity.membersAdded;
            for (let cnt = 0; cnt < membersAdded.length; ++cnt) {
                if (membersAdded[cnt].name !== "Bot") {
                    await context.sendActivity(`${membersAdded[cnt].name} joined the chat`);
                }
            }
            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });

        this.onMessage(async (context, next) => {
            var messageText = context.activity.text;
            await context.sendActivity(`Echo: ${messageText}`)
            await next()
        });
    }
}

module.exports.TeamsBot = TeamsBot;
